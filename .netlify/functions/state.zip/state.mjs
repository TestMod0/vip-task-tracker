
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/state.mts
import { getStore } from "@netlify/blobs";
var STORE_NAME = "vip-tracker";
var STATE_KEY = "state";
function getStateStore() {
  return getStore(STORE_NAME);
}
var state_default = async (req, context) => {
  const store = getStateStore();
  if (req.method === "GET") {
    const state = await store.get(STATE_KEY, { type: "json" }) ?? {};
    return new Response(JSON.stringify({ state }), {
      headers: { "content-type": "application/json" }
    });
  }
  if (req.method === "POST") {
    let body;
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "invalid json" }), {
        status: 400,
        headers: { "content-type": "application/json" }
      });
    }
    if (body && body.state && typeof body.state === "object") {
      await store.setJSON(STATE_KEY, body.state);
      return new Response(JSON.stringify({ ok: true }), {
        headers: { "content-type": "application/json" }
      });
    }
    const { id, field, value } = body || {};
    if (!id || !field) {
      return new Response(JSON.stringify({ error: "id and field are required" }), {
        status: 400,
        headers: { "content-type": "application/json" }
      });
    }
    const current = await store.get(STATE_KEY, { type: "json" }) ?? {};
    if (!current[id]) current[id] = {};
    current[id][field] = value;
    await store.setJSON(STATE_KEY, current);
    return new Response(JSON.stringify({ ok: true }), {
      headers: { "content-type": "application/json" }
    });
  }
  return new Response("Method not allowed", { status: 405 });
};
var config = {
  path: "/api/state"
};
export {
  config,
  state_default as default
};
